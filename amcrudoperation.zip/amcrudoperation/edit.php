<?php 
//Databse Connection file
include('dbconnection.php');
if(isset($_POST['submit']))
  {
    $eid=$_GET['editid'];
  //Getting Post Values
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $contno=$_POST['contactno'];
    $email=$_POST['email'];
    $dob=$_POST['dob'];
    $add=$_POST['address'];
 
    //Query for data updation
     $query=mysqli_query($con, "update  users_information set FirstName='$fname',LastName='$lname', MobileNumber='$contno', Email='$email', dob='$dob', Address='$add' where ID='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully update the data');</script>";
    echo "<script type='text/javascript'> document.location ='index.php'; </script>";
  }
  else
  {
    echo "<script>alert('Something Went Wrong. Please try again');</script>";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AM- CRUD Operation</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="edit_sec container">
    <h2>Crud Oparation #Edit User Information</h2>
    <form  method="POST">
      <?php
      $eid=$_GET['editid'];
      $ret=mysqli_query($con,"select * from users_information where ID='$eid'");
      while ($row=mysqli_fetch_array($ret)) {
      ?>
      <h2>Update</h2>
      <p class="hint-text">Update your info.</p>
      <div class="form-group">
        <div class="row">
          <div class="col">
            <input type="text" class="form-control" name="fname" value="<?php  echo $row['FirstName'];?>" required="true">
          </div>
          <div class="col">
            <input type="text" class="form-control" name="lname" value="<?php  echo $row['LastName'];?>" required="true">
          </div>
        </div>          
      </div>
       
      <div class="form-group">
        <input type="text" class="form-control" name="contactno" value="<?php  echo $row['MobileNumber'];?>" required="true" maxlength="10" pattern="[0-9]+">
      </div>
       
      <div class="form-group">
        <input type="email" class="form-control" name="email" value="<?php  echo $row['Email'];?>" required="true">
      </div>

      <div class="form-group">
        <input type="date" class="form-control" name="dob" value="<?php  echo $row['dob'];?>" required="true">
      </div>
          
      <div class="form-group">
        <textarea class="form-control" name="address" required="true"><?php  echo $row['Address'];?></textarea>
      </div>        
      <?php } ?>
      <div class="form-group">
        <button type="submit" class="btn btn-success btn-lg btn-block" name="submit">Update</button>
      </div>
    </form>
    
    <div class="row">
      <div class="col text-center">
        <a href="index.php" class="btn btn-success btn-info">Back to Index</a>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>