<?php 
//Databse Connection file
include('dbconnection.php');  
session_start();  
if(!isset($_SESSION["useremail"]))  
{  
header("location:login.php");  //?action=login
} 
$usemail= $_SESSION["useremail"]; 
$ref=mysqli_query($con,"select * from users_information where Email='".$usemail."'");
while ($row=mysqli_fetch_array($ref)) {
$refimg=base64_encode($row['UserImage']);
$reffname=$row['FirstName'];
}
?> 
<!DOCTYPE html>  
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title>Fully Monty</title>
		<meta name="description" content="" />
		<meta name="author" content="admin" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/animate.css" media="all" />
		<link href="css/multistep.css" rel="stylesheet">
        <link href="css/sweetalert.css" rel="stylesheet">
        <link href="css/easy-responsive-tabs.css" rel="stylesheet">
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/responsive.css" />
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	</head>
	<body>
	<header>
		<div class="container mobilee_view">
			<div class="ellipsis-circl">
				<a href="index.php"><i class="fal fa-ellipsis-v"></i></a>
			</div>
		</div>
		<div class="cus_nav">
			<div class="cus_nav_outr">
				<div class="container">
					<div class="cus_nav_innr">
						<div class="logo_area">
							<a href="index.php"><img class="img-fluid" src="images/logo.png" alt=""/></a>
						</div>
						<div class="nav_area">
							<div class="right_nav">
								<div class="navbar-header">
									<nav class="navbar navbar-expand-md">
										<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
											<span class="navbar-toggler-icon"></span>
										</button>
										<div class="collapse navbar-collapse" id="navbarNavDropdown">
											<ul class="navbar-nav">
												<li class="nav-item">
													<a class="nav-link" href="registration.php">Registration</a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="add-product.php">Add Product</a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="all-product.php">All Product</a>
												</li>
												<li class="nav-item">
													<a class="nav-link" href="best-seller.php">Best Selling Product</a>
												</li>
												<li class="nav-item">
													<a href="" data-toggle="modal" data-target="#exampleModal">Modal</a>
												</li>
											</ul>
										</div>
									</nav>
								</div>
								
								<div class="hdr-btn">
									<ul>
										<li class="ellipsis-circl dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fal fa-ellipsis-v"></i></a>
											
											<ul class="dropdown-menu">
												<li>
													<a href="web-design-package.html"> Transaction done by sri AMIT SETHIA.<br>
                                                      <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                    </a>
												</li>
											</ul>
										</li>
										
										<li class="dropdown drop-wdth notify-icn">
											<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bell-o" aria-hidden="true"></i>
											<?php if ( $_SESSION['loggedin'] = true ) { ?>
												<sup><img src="images/notify-icn-grn.png" alt=""/></sup>
											<?php }else{ ?>
												<sup><img src="images/notify-icn.png" alt=""/></sup>
											<?php } ?>
											</a>
											<ul class="dropdown-menu">
												<li>
													<a href="web-design-package.html"> Transaction done by sri AMIT SETHIA.<br>
                                                      <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                    </a>
												</li>
											</ul>
										</li>
										<li class="nav-item dropdown admin-boxes">
											<a href="javascript:void(0);" class="user-bx dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												<img src="data:image/jpg;charset=utf8;base64,<?php echo $refimg; ?>" width="40" height="40"/>
												<?php echo $reffname; ?></a>
											<ul class="dropdown-menu">
												<li><a href="web-design-package.html"> settings </a></li>
												<li><a href="user-profile.php">My Profile</a></li>
												</ul>
											</li>

										<li>
											<a href="logout.php" class="btn btn-primary logout"> Log Out </a>
										</li>
									</ul>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>