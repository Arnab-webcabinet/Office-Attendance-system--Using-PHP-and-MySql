<?php
//Databse Connection file
include('dbconnection.php');
?>

<?php include('header.php'); ?>
<?php
$refemail= $_SESSION["useremail"];
$ref=mysqli_query($con,"select ID from users_information where Email='".$refemail."'");
while ($row=mysqli_fetch_array($ref)) {
$refid=$row[0];
}

if(isset($_POST['contacsubmit']))
{	
    $fnm = mysqli_real_escape_string($con, $_POST['fname']);
    $lna = mysqli_real_escape_string($con, $_POST['lname']);
    $nconcat = $fnm." ".$lna;
    $eml = mysqli_real_escape_string($con, $_POST['email']); 
    $phn = mysqli_real_escape_string($con, $_POST['phone']);
    $add = mysqli_real_escape_string($con, $_POST['address']);
    $msg = mysqli_real_escape_string($con, $_POST['message']);
    /*--- Chec This Email id already exist or not ---*/
    $ret1=mysqli_query($con,"select * from contact_information_tbl where Email='".$eml."'");
  	if(mysqli_num_rows($ret1) > 0){
		echo "<script>alert('Email already exists..!');</script>";  
	}else{
	$query=mysqli_query($con, "insert into contact_information_tbl(ReferId, Name, Email, Phone, Address, Message) value('$refid','$nconcat','$eml', '$phn', '$add', '$msg')");
		if ($query) {
			echo "<script>alert('You have successfully inserted the data');</script>";
			echo "<script type='text/javascript'> document.location ='contact.php'; </script>";
		}
		else
		{
			echo "<script>alert('Something Went Wrong. Please try again');</script>";
		}
	}
}
?>

		<!--multistep section-->
		<section class="muttiform-details-sec">
			<div class="container">
				<div class="page-form-innr show-inn">
					<form id="msform" method="post" action="" enctype='multipart/form-data'>
						<div class="form-details-outr">
							<div class="frm-icon-outr text-center">
								<div class="frm-icon-innr">
									<img src="images/envalope1.png" alt=""/>
								</div>
							</div>
							
							<div class="comm-hdr text-center">
								<h3>GET IN TOUCH</h3>
								<p>We've got three ways for you to get in contact with us, depending on what you need help with.</p>
							</div>
							
							<div class="form-details-innr my-chk-input">
								<div class="row remove-mr">
									<div class="col-md-6">
										<div class="form-group">
											<label>FIRST Name :</label>
											<input type="text" name="fname" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>LAST NAME : </label>
											<input type="text" name="lname" class="form-control" placeholder="">
										</div>
									</div>
								</div>
								
								<div class="row remove-mr">
									<div class="col-md-4">
										<div class="form-group">
											<label>EMAIL :</label>
											<input type="email" name="email" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>PHONE :</label>
											<input type="tel" name="phone" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>ADDRESS :</label>
											<input type="text" name="address" class="form-control" placeholder="">
										</div>
									</div>
								</div>
								
								<div class="row remove-mr">
									<div class="col-md-12">
										<div class="form-group msg-rm">
											<label>ENTER YOUR MESSAGE :</label>
											<textarea class="form-control" name="message"></textarea>
										</div>
									</div>
									
								</div>
								
							</div>
						</div>
						
						<div class="text-center">
							<input type="submit" name="contacsubmit" class="btn btn-primary comm-btn register-btn" value="SUBMIT"/>
						</div>
					</form>
				</div>
			</div>
		</section>
		<!--end section-->

		<!--company details-->

		<section class="info-sec">
			<div class="container">
				<div class="info-outr">
					<div class="row">
						<div class="col-lg-4 col-md-4">
							<div class="info-bx">
								<div class="info-icn">
									<img src="images/info-icn1.png" alt=""/>
								</div>
								<div class="info-des">
									<h3>Add New Store</h3>
									<p>
										The <strong> first step </strong>is to choose how you want to position the store. 
									</p>
									<a href="all-withdrawals.html" class="btn btn-primary comm-btn actn-btn">Add Now</a>
								</div>
							</div>
						</div>

						<div class="col-lg-4 col-md-4">
							<div class="info-bx">
								<div class="info-icn">
									<img src="images/info-icn2.png" alt=""/>
								</div>
								<div class="info-des">
									<h3>FAQs</h3>
									<p>
									<strong> Frequently asked questions </strong>and answers on a particular topic.
									</p>
									<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">View</a>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="info-bx">
								<div class="info-icn">
									<img src="images/info-icn3.png" alt=""/>
								</div>
								<div class="info-des">
									<h3>Need Help?</h3>
									<p>
										If you <strong> need any type of help </strong> our services, we are always to help you.
									</p>
									<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">Get In TOuch</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

<?php include('footer.php'); ?>

