!!window['addEventListener'] && new WOW().init();

$('.digit-group').find('input').each(function() {
	$(this).attr('maxlength', 1);
	$(this).on('keyup', function(e) {
		var parent = $($(this).parent());
		
		if(e.keyCode === 8 || e.keyCode === 37) {
			var prev = parent.find('input#' + $(this).data('previous'));
			
			if(prev.length) {
				$(prev).select();
			}
		} else if((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
			var next = parent.find('input#' + $(this).data('next'));
			
			if(next.length) {
				$(next).select();
			} else {
				if(parent.data('autosubmit')) {
					parent.submit();
				}
			}
		}
	});
});

$('.archive-icn').on('click',function () {
    $(this).toggleClass('active');
});


jQuery(document).ready(function () {
jQuery('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = jQuery(this);
var $info = jQuery('#tabInfo');
var $name = jQuery('span', $info);
$name.text($tab.text());
$info.show();
}
});

});

$(document).ready(function () {
$(".save-in").css('display', 'none');
$(".edit-in").click(function() {
    $(this).addClass('edt');
    if ($(this).hasClass("edt")) {
	     $(this).next().css('display', 'block');
         $(this).parent('.inopen').addClass('prf-inn');
         $('.prf-inn input,.prf-inn textarea,.prf-inn select').removeAttr('disabled');
	} 
});
$(".save-in").click(function() {
     $(this).css('display', 'none');
     $(this).parents().find('.edit-in').removeClass('edt');
     $(this).addClass("svv");
     $(this).parent('.inopen').removeClass('prf-inn');
     $('.inopen input,.inopen textarea,.inopen select').attr('disabled', 'disabled');
}); 
}); 

$('.form-inn input').on('keyup', function(e){
    var val = $(this).val();
    var newval = '';
    val = val.replace(/\s/g, '');
    for(var i=0; i < val.length; i++) {
        if(i%4 == 0 && i > 0) newval = newval.concat(' ');
        newval = newval.concat(val[i]);
    }
    $(this).val(newval);
});