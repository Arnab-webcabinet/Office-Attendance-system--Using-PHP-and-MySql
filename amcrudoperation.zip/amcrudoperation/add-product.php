<?php 
include('dbconnection.php');
//Add catagory
if(isset($_POST['catagorysubmit']))
  {
    $cataname = mysqli_real_escape_string($con, $_POST['cate_name']);
    $catadesn = mysqli_real_escape_string($con, $_POST['cate_des']);

		$query=mysqli_query($con, "insert into product_catagory_tbl(CategoryName,	CategoryDescription) value('$cataname','$catadesn')");
		if ($query) {
		echo "<script>alert('You have successfully inserted Category');</script>";
		echo "<script type='text/javascript'> document.location ='add-product.php'; </script>";
		}
		else
		{
		echo "<script>alert('Something Went Wrong. Please try again');</script>";
		}
}

//Code for deletion
if(isset($_POST['productsubmit']))
{
	 $filename = $_FILES['productimg']['name'];
  	$target_dir = "upload/";
  	$target_file = $target_dir . basename($_FILES["productimg"]["name"]);
  	//getting the post values
    $sku = mysqli_real_escape_string($con, $_POST['sku']);
    $pnm = mysqli_real_escape_string($con, $_POST['product_name']);
    $pct = mysqli_real_escape_string($con, $_POST['product_ctgy']);
    $pco = mysqli_real_escape_string($con, $_POST['product_con']);
    $psd = mysqli_real_escape_string($con, $_POST['product_smldes']);
    $ppr = mysqli_real_escape_string($con, $_POST['regular_price']);
    $psp = mysqli_real_escape_string($con, $_POST['sale_price']);

		// Select file type
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		// Valid file extensions
		$extensions_arr = array("jpg","jpeg","png","gif");
		$profilefile = addslashes(file_get_contents($_FILES["productimg"]["tmp_name"]));

		// Check extension
		if( in_array($imageFileType,$extensions_arr) ){
		// Upload file
		if(move_uploaded_file($_FILES['productimg']['tmp_name'],$target_dir.$filename)){
		$query=mysqli_query($con, "insert into product_tbl(SKU,ProductName,ProductContent,	Product_small_description,ProductImage,product_category,product_regular_price,product_sale_price) value('$sku','$pnm','$pco','$psd','$profilefile','$pct','$ppr','$psp')");
		if ($query) {
		echo "<script>alert('You have successfully inserted Product..!');</script>";
		echo "<script type='text/javascript'> document.location ='add-product.php'; </script>";
		}
		else
		{
		echo "<script>alert('Something Went Wrong. Please try again');</script>";
		}
		} //end upload file or not 
		} //end check exist   
} 
?>

<?php include('header.php'); ?>

<section class="muttiform-details-sec">
	<div class="container">
		<div class="user-profile-outr">
		<div id="horizontalTab">
    	<ul class="resp-tabs-list clearfix">
        <li>
          <em><img src="images/tab-icon1.png" alt=""/></em>Add Category
        </li>
        <li>
          <em><img src="images/tab-icon3.png" alt=""/></em>Add Product
        </li>
        <li>
          <em><img src="images/tab-icon2.png" alt=""/></em>Product Reviews
        </li>
    	</ul>

    	<div class="resp-tabs-container">
        <div class="user-profile-innr">
        	<form id="cataform" method="post" action="" enctype='multipart/form-data'>
						<div class="form-details-outr">
							<div class="comm-hdr text-center">
								<h3>Add New Category</h3>
							</div>
							<div class="frm-icon-outr text-center">
								<div class="frm-icon-innr">
									<img src="images/register_topicon.png" alt=""/>
								</div>
							</div>
							<div class="form-details-innr my-chk-input">
								<div class="row remove-mr">
									<div class="col-md-4">
										<div class="form-group">
											<label>Category Name :</label>
											<input type="text" name="cate_name" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-8">
										<div class="form-group">
											<label>Category Description :</label>
											<textarea name="cate_des" class="form-control"></textarea>
										</div>
									</div>
									
								</div>
							</div>
						</div>
						<div class="text-center">
							<input type="submit" name="catagorysubmit" class="btn btn-primary comm-btn register-btn" value="Submit"/>
						</div>
					</form>
        </div>
        <div class="user-profile-innr">
          <form id="proform" method="post" action="" enctype='multipart/form-data'>
						<div class="form-details-outr">
							<div class="comm-hdr text-center">
								<h3>Add New Product</h3>
							</div>
							<div class="frm-icon-outr text-center">
								<div class="frm-icon-innr">
									<img src="images/register_topicon.png" alt=""/>
								</div>
							</div>
							<div class="form-details-innr my-chk-input">
								<div class="row remove-mr">
									<div class="col-md-4">
										<div class="form-group">
											<label>SKU :</label>
											<input type="text" name="sku" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Product Name :</label>
											<input type="text" name="product_name" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Product Category :</label>
											<select name="product_ctgy" class="form-control">
												<option>-Select Category-</option>
											<?php
											$catin=mysqli_query($con,"select * from product_catagory_tbl");
											while ($catlp=mysqli_fetch_array($catin)) {
											$catn=$catlp['CategoryName'];
											?>
												<option value="<?php echo $catn; ?>"><?php echo $catn; ?></option>
											<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Product Content :</label>
											<textarea name="product_con" class="form-control"></textarea>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Product Small Description :</label>
											<textarea name="product_smldes" class="form-control"></textarea>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Product Image :</label>
											<div class="file-upload uploader">
												<input id="file-upload" type="file" type="file" name="productimg" accept="image/*" />

												<label for="file-upload" id="file-drag"> <img id="file-image" src="#" alt="Preview" class="hidden">
													<div id="start">
														<img src="images/fileup_img.png" alt="d">
														<h5>File Size
														<br>
														250*250 pixel</h5>
														<div id="notimage" class="hidden">
															img
														</div>
													</div>
													<div id="response" class="hidden">
														<div id="messages"></div>
													</div>
												</label>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Regular Price :</label>
											<input type="text" name="regular_price" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label>Sale Price :</label>
											<input type="text" name="sale_price" class="form-control" placeholder="">
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<div class="text-center">
							<input type="submit" name="productsubmit" class="btn btn-primary comm-btn register-btn" value="Submit"/>
						</div>
					</form>
        </div>
        <div class="user-profile-innr"></div>
    	</div>
    </div>
  	</div>
	</div>
</section>

<?php include('footer.php'); ?>