<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title>Fully Monty</title>
		<meta name="description" content="" />
		<meta name="author" content="admin" />
		<meta name="viewport" content="width=device-width; initial-scale=1.0" />
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/animate.css" media="all" />
		<link href="css/multistep.css" rel="stylesheet">
        <link href="css/sweetalert.css" rel="stylesheet">
        <link href="css/easy-responsive-tabs.css" rel="stylesheet">
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/responsive.css" />
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	</head>
	<body>
		<header>
			<div class="container mobilee_view">
				<div class="ellipsis-circl"><a href="javascript:void(0);"><i class="fal fa-ellipsis-v"></i></a></div>
			</div>
			<div class="cus_nav">
				<div class="cus_nav_outr">
					<div class="container">
						<div class="cus_nav_innr">
							<div class="logo_area">
								<a href="admin-store.html"><img class="img-fluid" src="images/logo.png" alt=""/></a>
							</div>
							<div class="nav_area">
								<div class="right_nav">
									<div class="navbar-header">
										<nav class="navbar navbar-expand-md">
											<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
												<span class="navbar-toggler-icon"></span>
											</button>
											<div class="collapse navbar-collapse" id="navbarNavDropdown">
												<ul class="navbar-nav">
													<li class="nav-item">
														<a class="nav-link" href="admin-store.html">Home</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" href="sm-registration.html">Registration</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" href="sm-withdrawals.html">Withdrawals</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" href="sm-transaction.html">Transactions</a>
													</li>

												</ul>
											</div>
										</nav>
									</div>
									<div class="hdr-btn">
										<ul>
											<li class="ellipsis-circl dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fal fa-ellipsis-v"></i></a>
												
												<ul class="dropdown-menu">
													<li>
														<a href="web-design-package.html"> Transaction done by sri AMIT SETHIA.<br>
                                                          <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
													<li>
														<a href="seo-package.html">Transaction done by Goutam Gope. <br>
                                                        <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
													<li>
														<a href="seo-package.html">Transaction done by Goutam Gope. <br>
                                                        <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
												</ul>
											</li>
											
											<li class="dropdown drop-wdth notify-icn">
												<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell-o" aria-hidden="true"></i> <sup> <img src="images/notify-icn.png" alt=""/></sup> </a>
												<ul class="dropdown-menu">
													<li>
														<a href="web-design-package.html"> Transaction done by sri AMIT SETHIA.<br>
                                                          <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
													<li>
														<a href="seo-package.html">Transaction done by Goutam Gope. <br>
                                                        <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
													<li>
														<a href="seo-package.html">Transaction done by Goutam Gope. <br>
                                                        <i class="fa fa-calendar" aria-hidden="true"><em>13/3/2020</em></i>  
                                                        </a>
													</li>
												</ul>
											</li>
											<li class="nav-item dropdown admin-boxes">
												<a href="javascript:void(0);" class="user-bx dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="images/admin-icn.png" alt=""/>Store</a>
												<ul class="dropdown-menu">
													<li><a href="web-design-package.html"> settings </a></li>
													<li><a href="sm-user-profile.html">My Profile</a></li>
													</ul>
												</li>

											<li>
												<a href="login.html" class="btn btn-primary logout"> Log Out </a>
											</li>
										</ul>

									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</header>
        
<!--  end header  -->
<!-- user profile section   -->
        <section class="user-profile-sec">
            <div class="container">
                <div class="user-profile-outr">
                <div id="horizontalTab">
                <ul class="resp-tabs-list clearfix">
                    <li>
                       <em><img src="images/tab-icon1.png" alt=""/></em>Business Information
                    </li>
                    <li>
                       <em><img src="images/tab-icon2.png" alt=""/></em>Financial Information
                    </li>
                    <li>
                        <em><img src="images/tab-icon3.png" alt=""/></em>Account Settings
                    </li>
                </ul>

                <div class="resp-tabs-container">
                    <div class="user-profile-innr">
                        <form>
                            <div class="row space-inn">
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>NAME</label>
                                        <input type="text" class="form-control" placeholder="Chrish Jordon" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                    <div class="form-group inopen">
                                        <label>Email address</label>
                                        <input type="email" class="form-control" placeholder="info@message.com" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                    <div class="form-group inopen">
                                        <label>address</label>
                                        <textarea class="form-control" placeholder="201 N Main St, Hannibal, MO 63401, United State" disabled></textarea>
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                    <div class="form-group inopen">
                                        <label>Phone No</label>
                                        <input type="tel" class="form-control" placeholder="+1 573-406-3892" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group upld-innr">
                                        <label>Update Profile Picture <br> <strong>Drag file here to upload or</strong></label>
                                        <div class="file-upload uploader">
                                            <input id="file-upload" type="file" name="fileUpload" accept="image/*" />
                                            <label for="file-upload" id="file-drag"> <img id="file-image" src="#" alt="Preview" class="hidden">
                                                <div id="start">
                                                    <img src="images/upld.png" alt="d">
                                                    <br>
                                                    <em class="upld-btn">Upload</em>
                                                    <h6>Max size of 4mb
                                                    <br>
                                                    Max dimensions 300px * 300px</h6>
                                                    <div id="notimage" class="hidden">
                                                        img
                                                    </div>
                                                </div>
                                                <div id="response" class="hidden">
														<div id="messages"></div>
													</div> 
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                                       <div class="user-profile-innr">
                        <form>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-inn">
                                        <h4>Your preferred Payment Mode</h4>
                                        <div class="form-group inopen">
                                            <label>Credit Card</label>
                                            <input type="text" class="form-control" name="number"  placeholder="Visa credit ****6469" maxlength="16" disabled />
                                            <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                            <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-inn">
                                        <h4>Bank account</h4>
                                        <div class="form-group inopen">
                                            <label>ICICI Bank</label>
                                            <input type="text" class="form-control" name="number" placeholder="Account No ****6629" maxlength="16" disabled />
                                            <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                            <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-inn">
                                        <h4>Card No</h4>
                                        <div class="form-group inopen"> 
                                            <label>Credit Card</label>
                                            <input type="text" class="form-control" name="number" placeholder="Visa credit ****6469" maxlength="16" disabled />
                                            <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                            <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-inn">
                                        <h4>Automatic withdrawal To</h4>
                                        <div class="form-group inopen">
                                            <label>Credit Card</label>
                                            <input type="text" class="form-control" name="number" placeholder="Visa credit ****6469" maxlength="16" disabled />
                                            <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                            <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="user-profile-innr">
                        <form>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Account type</label>
                                        <input type="text" class="form-control" placeholder="Business" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Notifications</label>
                                        <input type="text" class="form-control" placeholder="Send me alerts when the account is updated" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Manage users</label>
                                        <input type="text" class="form-control" placeholder="Only you can update your profile" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Stay logged in</label>
                                        <input type="text" class="form-control" placeholder="Manage devices and browsers" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Password</label>
                                        <input type="password" class="form-control" placeholder="Present Password ****29" disabled />
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group inopen">
                                        <label>Time zone</label>
                                        <select class="form-control" disabled>
                                            <option value="">Pacific Standard Time (PST) - 08:00</option>
                                            <option value="">Pacific Standard Time (PST) - 08:00</option>
                                            <option value="">Pacific Standard Time (PST) - 08:00</option>
                                            <option value="">Pacific Standard Time (PST) - 08:00</option>
                                            <option value="">Pacific Standard Time (PST) - 08:00</option>
                                        </select>
                                        <span class="btn-edit edit-in"><img src="images/read.png" alt=""/></span>
                                        <span class="btn-save save-in"><i class="fa fa-times" aria-hidden="true"></i></span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
            </div>
        </section>
<!--  end section  -->
<!--  footer     -->
		<footer class="footer">
			<div class="top-footer">
				<div class="container">
					<div class="ftr-menu">
						<ul>
							<li>
								<a href="conatct.html">Contact Us </a>
							</li>
							<li>
								<a href="privacy.html"> Privacy </a>
							</li>
							<li>
								<a href="terms.html">Terms </a>
							</li>
							<li>
								<a href="javascript:void(0);"> © TFM Finance. 2020.</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<!-- footer -->

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
		<!-- Popper JS -->
		
		<!-- Latest compiled JavaScript -->
		<script src="js/wow.min.js" ></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
		<script src="js/multistep.js"></script>
        
        <script src="js/file-download.js"></script>
        <script src="js/easy-responsive-tabs.js"></script>
		<script src="js/custom.js"></script>
		<script type="text/javascript">
	    $(function () {
	        $("input[name='chkPassPort']").click(function () {
                $("#txtPassportNumber").removeAttr("disabled");
                $("#txtPassportNumber").focus();
	        });
	    });
		</script>
		<script>
			var maxHeight = 0;

			$(".info-bx").each(function() {
				if ($(this).height() > maxHeight) {
					maxHeight = $(this).height();
				}
			});

			$(".info-bx").height(maxHeight);

		</script>

		<script>
			$(document).ready(function() {
				//change colour when radio is selected
				$('#radio-example input:radio').change(function() {
					// Only remove the class in the specific `box` that contains the radio
					$('div.highlight').removeClass('highlight');
					$(this).closest('.create-innr').addClass('highlight');
				});
			});

		</script>

		<script>
			$(function() {
				$(".clk").click(function() {
					$(".hide-inn").addClass("show-inn");
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".reset-btn").click(function() {
					$("#remove").removeClass("page-form-innr").addClass('xyz');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".next-btn").click(function() {
					$("#remove").removeClass("xyz over-follow").addClass('page-form-innr over-follow');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".reset-btn").click(function() {
					$("#progressbar").removeClass("pregress-innr").addClass('xyz');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".next-btn").click(function() {
					$("#progressbar").removeClass("xyz").addClass('pregress-innr');
				});
			});
		</script>

		<script>
			var expiryMask = function() {
				var inputChar = String.fromCharCode(event.keyCode);
				var code = event.keyCode;
				var allowedKeys = [8];
				if (allowedKeys.indexOf(code) !== -1) {
					return;
				}

				event.target.value = event.target.value.replace(/^([1-9]\/|[2-9])$/g, '0$1/').replace(/^(0[1-9]|1[0-2])$/g, '$1/').replace(/^([0-1])([3-9])$/g, '0$1/$2').replace(/^(0?[1-9]|1[0-2])([0-9]{2})$/g, '$1/$2').replace(/^([0]+)\/|[0]+$/g, '0').replace(/[^\d\/]|^[\/]*$/g, '').replace(/\/\//g, '/');
			}
			var splitDate = function($domobj, value) {
				var regExp = /(1[0-2]|0[1-9]|\d)\/(20\d{2}|19\d{2}|0(?!0)\d|[1-9]\d)/;
				var matches = regExp.exec(value);
				$domobj.siblings('input[name$="expiryMonth"]').val(matches[1]);
				$domobj.siblings('input[name$="expiryYear"]').val(matches[2]);
			}

			$('input.exp').on('keyup', function() {
				expiryMask();
			});

			$('input.exp').on('focusout', function() {
				splitDate($(this), $(this).val());
			});
		</script>

		<script>
class CreditCard{
constructor(inputObject){

//Safety check
if(typeof inputObject !== "object"){
console.log("Error in creating card object! Passed argument must be an object!");
return null;
}
else{
this.num = "";
this.chkNum = "";

//Generate the input string
for(let inputField of inputObject){
this.num += inputField.value;
}

//apply Luhn algorithm on card number
for( var j = 0; j < this.num.length; j++ ){
if( j % 2 === 0 ){
this.chkNum += this.luhn( this.num[j] );
}
else{
this.chkNum += this.num[j];
}
} //for end
} //else end
} //constructor end

isValid(){
var sum = 0;
for(let number of this.chkNum){
sum += parseInt(number);
}

return sum % 10 === 0;
}

luhn(num){
if(typeof num !== "string"){
console.log("Card.prototype.luhn error: argument is not a string!");
return;
}
num = parseInt(num);
var checkNum = num * 2;
return checkNum > 9 ? checkNum - 9 : checkNum;
}

printValidity(){
if(this.chkNum.length !== 16){
result.innerHTML = "Invalid input length.";
}
else if( this.isValid( this.chkNum ) ){
result.innerHTML = "Your card number is valid!";
} else{
result.innerHTML = "Your card number is invalid!";
}
};
}

let btn = document.querySelector("#check");
btn.addEventListener("click", () => {
let fields = document.querySelectorAll(".fl1");
let result = document.getElementById( "result" );

let card = new CreditCard(fields);
card.printValidity();
});

const fields = document.querySelectorAll(".fl1");
for(let field of fields){
field.addEventListener("keyup", function(){
if(field.value.length >= field.getAttribute("maxlength")){
field.nextElementSibling.focus();
}
});
}
		</script>

		<script type="text/javascript">
			function ekUpload() {
				function Init() {

					console.log("Upload Initialised");

					var fileSelect = document.getElementById('file-upload'), fileDrag = document.getElementById('file-drag'), submitButton = document.getElementById('submit-button');

					fileSelect.addEventListener('change', fileSelectHandler, false);

					// Is XHR2 available?
					var xhr = new XMLHttpRequest();
					if (xhr.upload) {
						// File Drop
						fileDrag.addEventListener('dragover', fileDragHover, false);
						fileDrag.addEventListener('dragleave', fileDragHover, false);
						fileDrag.addEventListener('drop', fileSelectHandler, false);
					}
				}

				function fileDragHover(e) {
					var fileDrag = document.getElementById('file-drag');

					e.stopPropagation();
					e.preventDefault();

					fileDrag.className = (e.type === 'dragover' ? 'hover' : 'modal-body file-upload');
				}

				function fileSelectHandler(e) {
					// Fetch FileList object
					var files = e.target.files || e.dataTransfer.files;

					// Cancel event and hover styling
					fileDragHover(e);

					// Process all File objects
					for (var i = 0, f; f = files[i]; i++) {
						parseFile(f);
						uploadFile(f);
					}
				}

				// Output
				function output(msg) {
					// Response
					var m = document.getElementById('messages');
					m.innerHTML = msg;
				}

				function parseFile(file) {

					console.log(file.name);
					output('<h5>' + encodeURI(file.name) + '</h5>');

					// var fileType = file.type;
					// console.log(fileType);
					var imageName = file.name;

					var isGood = (/\.(?=gif|jpg|png|jpeg)/gi).test(imageName);
					if (isGood) {
						document.getElementById('start').classList.add("hidden");
						document.getElementById('response').classList.remove("hidden");
						document.getElementById('notimage').classList.add("hidden");
						// Thumbnail Preview
						document.getElementById('file-image').classList.remove("hidden");
						document.getElementById('file-image').src = URL.createObjectURL(file);
					} else {
						document.getElementById('file-image').classList.add("hidden");
						document.getElementById('notimage').classList.remove("hidden");
						document.getElementById('start').classList.remove("hidden");
						document.getElementById('response').classList.add("hidden");
						document.getElementById("file-upload-form").reset();
					}
				}

				function setProgressMaxValue(e) {
					var pBar = document.getElementById('file-progress');

					if (e.lengthComputable) {
						pBar.max = e.total;
					}
				}

				function updateFileProgress(e) {
					var pBar = document.getElementById('file-progress');

					if (e.lengthComputable) {
						pBar.value = e.loaded;
					}
				}

				function uploadFile(file) {

					var xhr = new XMLHttpRequest(), fileInput = document.getElementById('class-roster-file'), pBar = document.getElementById('file-progress'), fileSizeLimit = 1024;
					// In MB
					if (xhr.upload) {
						// Check if file is less than x MB
						if (file.size <= fileSizeLimit * 1024 * 1024) {
							// Progress bar
							pBar.style.display = 'inline';
							xhr.upload.addEventListener('loadstart', setProgressMaxValue, false);
							xhr.upload.addEventListener('progress', updateFileProgress, false);

							// File received / failed
							xhr.onreadystatechange = function(e) {
								if (xhr.readyState == 4) {
									// Everything is good!

									// progress.className = (xhr.status == 200 ? "success" : "failure");
									// document.location.reload(true);
								}
							};

							// Start upload
							xhr.open('POST', document.getElementById('file-upload-form').action, true);
							xhr.setRequestHeader('X-File-Name', file.name);
							xhr.setRequestHeader('X-File-Size', file.size);
							xhr.setRequestHeader('Content-Type', 'multipart/form-data');
							xhr.send(file);
						} else {
							output('Please upload a smaller file (< ' + fileSizeLimit + ' MB).');
						}
					}
				}

				// Check for the various File API support.
				if (window.File && window.FileList && window.FileReader) {
					Init();
				} else {
					document.getElementById('file-drag').style.display = 'none';
				}
			}

			ekUpload();
		</script>
<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawCharts);
function drawCharts() {
  // actual bar chart data
  var barData = google.visualization.arrayToDataTable([
    ['Day', 'Net Income', 'Withdrawn'],
    ['Mon',  6000, 920],
    ['Tue',  24000, 15000],
    ['Wed',  8000, 1400],
    ['Thu',  4900, 4700],
    ['Fri',  19020, 17500],
    ['Sat',  15000, 14700],
    ['Sun',  6000, 4200]
  ]);
  // set bar chart options
  var barOptions = {
    focusTarget: 'category',
    backgroundColor: 'transparent',
    colors: ['#3358dd', '#33dd9b'],
    fontName: 'Open Sans',
    chartArea: {
      left: 50,
      top: 10,
      width: '100%',
      height: '70%'
    },
    bar: {
      groupWidth: '20%'
    },
    hAxis: {
      textStyle: {
        fontSize: 15,
        color: '#1e232a'
      }
    },
    vAxis: {
      minValue: 0,
      /*content: "\0024";*/
      maxValue: 25000,
      baselineColor: '#DDD',
      gridlines: {
        color: '#DDD',
        count: 6
      },
      textStyle: {
        fontSize: 15,
        color: '#1e232a'
      }
    },
    legend: {
      position: 'bottom',
      textStyle: {
        fontSize: 12
      }
    },
    animation: {
      duration: 1200,
      easing: 'out',
			startup: true
    }
  };
  // draw bar chart twice so it animates
  var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart'));
  //barChart.draw(barZeroData, barOptions);
  barChart.draw(barData, barOptions);
  
  // BEGIN LINE GRAPH
  
  function randomNumber(base, step) {
    return Math.floor((Math.random()*step)+base);
  }
  function createData(year, start1, start2, step, offset) {
    var ar = [];
    for (var i = 0; i < 12; i++) {
      ar.push([new Date(year, i), randomNumber(start1, step)+offset, randomNumber(start2, step)+offset]);
    }
    return ar;
  }
  var randomLineData = [
    ['Year', 'Page Views', 'Unique Views']
  ];
  for (var x = 0; x < 7; x++) {
    var newYear = createData(2007+x, 10000, 5000, 4000, 800*Math.pow(x,2));
    for (var n = 0; n < 12; n++) {
      randomLineData.push(newYear.shift());
    }
  }
  var lineData = google.visualization.arrayToDataTable(randomLineData);

}
		</script>



	</body>
</html>

