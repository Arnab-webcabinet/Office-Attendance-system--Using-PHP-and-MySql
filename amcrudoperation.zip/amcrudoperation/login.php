<?php 
session_start();
include('dbconnection.php');
?>

<?php 
if(isset($_POST['login']))
{
	$gtip=$_SERVER['REMOTE_ADDR']; // Client IP
	if (empty($_POST['useremail']) && empty($_POST['password'])) {
		echo "<script>alert('Both field are required..!');</script>";
	} else {
		$useremail = mysqli_real_escape_string($con, $_POST['useremail']);
		$password = mysqli_real_escape_string($con, $_POST['password']);
		$password = md5($password);

		// echo "select * from users_information WHERE Email='".$useremail."' AND Password='".$password."'";
		// echo "<br/> 24b30ddfe6f27c51809dbe622fe401"; 

	$result=mysqli_query($con,"select * from users_information WHERE Email='".$useremail."' AND Password='".$password."'");
	$num_row = mysqli_num_rows($result);
	$row=mysqli_fetch_array($result);
	$userid=$row['ID'];
	if($num_row >0) {
		$_SESSION['luser'] = $useremail;
		$_SESSION['start'] = time();
		// taking now logged in time
		$_SESSION['expire'] = $_SESSION['start'] + (5 * 60) ;
		mysqli_query($con, "insert into login_tbl(login_id,login_email,user_ip) value('$userid','$useremail','$gtip')");
		echo "<script>alert('You have successfully Login');</script>";
		$_SESSION['useremail']=$useremail; 
		//header("location:header.php");  		
		header("location:index.php");  		
	}
	else{
		echo "<script>alert('your Login fail. Please insert currect userid and password.');</script>";
		$_SESSION['error'] = "<div class='alert alert-danger' role='alert'>Oh snap! Invalid login details.</div>";
	}
	}
}
?>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title>Fully Monty</title>
		<meta name="description" content="" />
		<meta name="author" content="admin" />
		<meta name="viewport" content="width=device-width; initial-scale=1.0" />
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.12.0/css/all.css">
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link href="css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/animate.css" media="all" />
		<link href="css/multistep.css" rel="stylesheet">
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/responsive.css" />
	</head>
	<body class="log-body">
		<!--login details-->
    <section class="login-sec">
      <div class="container">
        <div class="login-otr">
				<div class="login-innr">
          <div class="financ">
            <a href="javascript:void(0);" class="finan-img">
              <div class="finan-crcl">
                <img src="images/finan-img.png" alt=""/>
              </div>
            </a>
            <div class="comm-hdr text-center">
        			<h3>Login</h3>
              <p>Login here using your email and password</p>
            </div>
            <form action="" method="post" class="innr-form login-form box-shdw">
              <div class="row">
                <div class="form-group col-lg-12 col-sm-12">
                  <input type="email" class="form-control" placeholder="email" id="useremail" name="useremail" value="" />  
                </div>
              </div>
              <div class="row">
                <div class="form-group col-lg-12 col-sm-12">
                  <input type="password" class="form-control" placeholder="Password" id="password" name="password" value="" />  
                </div>
              </div>
              <div class="join_btn text-center">
             		<input type="submit" value="Login" class="btn btn-primary sub-btn" id="login" name="login">
              </div>
            </form>
            <div class="forgot-pswd">
              <a href="javascript:void(0);" class="frd-btn">Forgot your password?</a> |
              <a href="registration.php" class="frd-btn" target="_blank"><strong>New Register</strong></a>
            </div>
          </div>
        </div>
      	</div>
       </div>
    </section>

		<!--  footer     -->
		<footer class="footer ft-ab">
			<div class="top-footer">
				<div class="container">
					<div class="ftr-menu">
						<ul>
							<li>
								<a href="conatct.html">Contact Us </a>
							</li>
							<li>
								<a href="privacy.html"> Privacy </a>
							</li>
							<li>
								<a href="terms.html">Terms </a>
							</li>
							<li>
								<a href="javascript:void(0);"> © TFM Finance. 2020.</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<!-- footer -->

		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="js/wow.min.js" ></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
		<script src="js/multistep.js"></script>
		<script src="js/custom.js"></script>

		
	</body>
</html>

