<?php 
//Databse Connection file
include('dbconnection.php');  
// session_start();  
// if(!isset($_SESSION["useremail"]))  
// {  
// header("location:login.php?action=login");  
// } 
// $usemail= $_SESSION["useremail"]; 
?> 

<?php include('header.php'); ?>

<script type="text/javascript">
	$(document).ready(function(){
		$("#search").keyup(function(){
			$.ajax({
				url: 'searchbackend.php',
				type: 'post',
				data: {search: $(this).val()},
				success: function(result) {
					$("#result").html(result);
				}
			});
		});
	});
</script>

<section class="views-all-store-sec admin-store-sec ">
	<div class="container">
		<div class="transacton-outr">
			<div class="transaction-innr">
				<div class="available-outr store-name-outr">
					<div class="available-bx">
						<div class="store-name-logo">
							<img src="images/store-name-logo.png" alt=""/>
						</div>
						<div class="store-name-details">
							<ul>
								<li><strong>Store Name :</strong> <span>hih7 webtech pvt ltd</span>  </li>
								<li><strong>address :</strong> <span> Holdrege, NE 68949, United State </span></li>
								<li><strong>EMAIL : </strong>  <span><a href="mailto: info@hih7.com"> info@hih7.com</a> </span></li>
               					<li><strong>Phone :  </strong><span> <a href="tel:+13089958446"> +1 308-995-8446</a></span> </li>
							</ul>
						</div>
					</div>
				</div>
				
				<div class="commn-border">
					<div class="all-store-manager-box">
						<div class="comm-innr-hdr">
							<h3>Monthly Revenue </h3>
							<div class="notification-btn dropdown">
								<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fal fa-ellipsis-v"></i></a>
								<ul class="dropdown-menu">
									<li>
										<a href="web-design-package.html"> Lorem </a>
									</li>
									<li>
										<a href="seo-package.html">Lorem</a>
									</li>
									<li>
										<a href="seo-package.html">Lorem</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="wrapper"><canvas id="chart-0"></canvas></div>
					</div>
				</div>
			</div>
		
		
		<div class="total-earning-outr">
			<div class="total-innr-bx">
				<div class="total-innr-txt-outr">
					<div class="total-innr-txt">
						<h3>Total<br />balance</h3>
					</div>
				</div>
				<div class="totl-ear-crcl-outr">
				  <div class="totl-ear-crcl">
						<div class="blanc-amont">
							<h1>$0.00</h1>
							<h2>USD</h2>
						</div>
					</div>
                </div>
			</div>
			
			<div class="total-innr-bx">
				<div class="total-innr-txt-outr">
					<div class="total-innr-txt">
						<h3>Total <br /> tips</h3>
					</div>
				</div>
				<div class="totl-ear-crcl-outr">
				  <div class="totl-ear-crcl">
						<div class="blanc-amont">
							<h1>150+</h1>
							<h2>SA</h2>
						</div>
					</div>
                </div>
			</div>
			
			<div class="total-innr-bx">
				<div class="total-innr-txt-outr">
					<div class="total-innr-txt">
						<h3>Top sales<br /> associates </h3>
					</div>
				</div>
				<div class="totl-ear-crcl-outr">
				  <div class="totl-ear-crcl">
						<div class="blanc-amont">
							<h1>$0.00</h1>
							<h2>USD</h2>
						</div>
					</div>
                </div>
				
			</div>
			
		</div>
		
		
		<div class="commn-border">
			<div class="comm-hdr text-center">
				<h3>View All Sales Associates</h3>
			</div>

			<div class="search-outr">
				<input type="text" id="search" placeholder="Search by Name and phone No.." class="form-control">
				<!-- <input type="submit" class="frm-sbmt" value="Search"> -->
			</div>

			<div class="all-store-manager-box str-nam-rmv">
				<h3>All User Information</h3>		
				<div class="table-overflow">
				<div class="table-width">
					<table class="table table-striped">
					    <thead>
					      <tr>
					        <th>#</th>
					        <th>Profile Img.</th>
					        <th>Name</th>
					        <th>Email</th>
					        <th>Phone No.</th>
					        <th>Date</th>
					        <th>Action</th>
					      </tr>
					    </thead>
					    <tbody id="result">
					    <?php
						$ret=mysqli_query($con,"select * from users_information");
						$cnt=1;
						$row=mysqli_num_rows($ret);
						if($row>0){
						while ($row=mysqli_fetch_array($ret)) {
						$timestamp = strtotime($row['CreationDate']);
						$getodt = date('d-m-Y', $timestamp);
						?>
							<tr>
								<td><?php echo $cnt;?></td>
								<td><img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['UserImage']); ?>" width="60" height="60"></td> 
								<td><?php echo $row['FirstName'];?> <?php  echo $row['LastName'];?></td>
								<td><a href="mailto:<?php echo $row['Email'];?>"><?php echo $row['Email'];?></a></td> 
								<td><a href="tel:<?php echo $row['MobileNumber'];?>"><?php echo $row['MobileNumber'];?></a></td>                       
								<td><?php echo $getodt;?></td>
								<td>
								<div class="action-btn">
									<a href="edit.php?editid=<?php echo htmlentities ($row['ID']);?>" class="archive-icn"><img src="images/edit.png" alt=""/></a>
									<a href="read.php?viewid=<?php echo htmlentities ($row['ID']);?>"><img src="images/view-icn.png" alt=""/></a>
									<a href="register.php?delid=<?php echo ($row['ID']);?>" title="Delete" data-toggle="tooltip" onclick="return confirm('Do you really want to Delete ?');"><img src="images/delete-icn.png" alt=""/></a>
								</div>
								</td>
							</tr>
							<?php 
							$cnt=$cnt+1;
							} } else {?>
					     	<tr>
								<td style="text-align:center; color:red;" colspan="7">No Record Found</td>
							</tr>
							<?php } ?> 
					    </tbody>
					</table>
				</div>
				</div>
				<div class="pagination-outr">
					<div class="per-page">
						<ul>
							<li>
								<div class="box">
									<select>
										<option> 10 per Page</option>
										<option>5 per Page</option>
									</select>
								</div>
							</li>
							<li>
								<a href="javascript:void(0);">Prev.</a>
							</li>
							<li>
								<a href="javascript:void(0);">Next</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</section>

<section class="info-sec innertr_fooinfo">
	<div class="container">
		<div class="info-outr">
			<div class="row">
				<div class="col-lg-6 col-md-6">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/amff_icon1.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Withdraw Funds </h3>
							<a href="sm-withdrawals.html" class="btn btn-primary comm-btn actn-btn">Withdrawals</a>
						</div>
					</div>
				</div>

				<div class="col-lg-6 col-md-6">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/amff_icon2.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>View Transactions</h3>
							<a href="sm-transaction.html" class="btn btn-primary comm-btn actn-btn">Transactions</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ammodhdr">
        <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="ml_hdr">
	     <p>Hello Valued Clients,</p>
	  	</div>

		<p>We are happy to announce our new updated website!  Starting on Wednesday, February 2nd, you will see the new layout. Basic card processing functionality is the same with our Standard and Contactless types.</p>

 		<p>Your credentials and store set ups are the exact same, it’s just a new look and some added features:</p>
		<ul>
			<li>Refund Processing – refunds will now be done by you!  Simply look up the transaction and press refund, pick the Store Manager on duty who will get a OTP to allow the refund to post.</li>
			<li>Chargebacks – you will now be able to see all chargebacks and status of each chargeback as we work through each one.</li>
			<li>Security Features – when you run cards, we have added some features to protect from further chargebacks:
				<ul>
					<li>Cards can be processed two times per day, if a person tries to run their card more than that the system won’t allow for it.  We see many fraudulent charges where the person tests a small transaction to see if it works, then proceeds to charge several more times in the same day before the owner of the card notices.</li>
					<li>Anyone who completes a chargeback will be blocked from using FHL’s system anywhere in the future.</li>
					<li>A prompt for the Sales Associate to confirm if the ID matches the credit card name before proceeding to make sure a customer is not using another person’s card.</li>
				</ul>
			</li>
			<li>Clearer Reports – more detailed reports showing the details of what makes up the balance being deposited for the day.</li>
		</ul>
 	
		<p>We are excited to hear your feedback as you experience a more streamlined quicker responsive website.</p>

 		<p>If you would like any training or a walk-through of the new website for yourself or your team please select a time here:</p>

 		<p><a href="https://calendly.com/guardianbankingsolutions/training-session">https://calendly.com/guardianbankingsolutions/training-session</a></p>

 
 		<div class="ml_ftr">
 			<p>Thank you!</p>
 			<p>Gary Viramontes</p>
 		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php include('footer.php'); ?>