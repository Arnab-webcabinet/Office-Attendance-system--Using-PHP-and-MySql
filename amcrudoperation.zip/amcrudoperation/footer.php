<!--  footer     -->
		<footer class="footer">
			<div class="top-footer">
				<div class="container">
					<div class="ftr-menu">
						<ul>
							<li>
								<a href="contact.php">Contact Us </a>
							</li>
							<li>
								<a href="privacy.php">Privacy</a>
							</li>
							<li>
								<a href="terms.php">Terms </a>
							</li>
							<li>
							<a href="javascript:void(0);"> © TFM Finance. <?php echo date('Y'); ?>.</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<!-- footer -->
		
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="js/wow.min.js" ></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
		<script src="js/multistep.js"></script>
		<script src="js/easy-responsive-tabs.js"></script>
		<script src="js/Chart.min.js"></script>
		<script src="js/utils.js"></script>
        <script src="js/file-download.js"></script>
		<script src="js/custom.js"></script>
		<script type="text/javascript">
			function ekUpload() {
				function Init() {

					console.log("Upload Initialised");

					var fileSelect = document.getElementById('file-upload'), fileDrag = document.getElementById('file-drag'), submitButton = document.getElementById('submit-button');

					fileSelect.addEventListener('change', fileSelectHandler, false);

					// Is XHR2 available?
					var xhr = new XMLHttpRequest();
					if (xhr.upload) {
						// File Drop
						fileDrag.addEventListener('dragover', fileDragHover, false);
						fileDrag.addEventListener('dragleave', fileDragHover, false);
						fileDrag.addEventListener('drop', fileSelectHandler, false);
					}
				}

				function fileDragHover(e) {
					var fileDrag = document.getElementById('file-drag');

					e.stopPropagation();
					e.preventDefault();

					fileDrag.className = (e.type === 'dragover' ? 'hover' : 'modal-body file-upload');
				}

				function fileSelectHandler(e) {
					// Fetch FileList object
					var files = e.target.files || e.dataTransfer.files;

					// Cancel event and hover styling
					fileDragHover(e);

					// Process all File objects
					for (var i = 0, f; f = files[i]; i++) {
						parseFile(f);
						uploadFile(f);
					}
				}

				// Output
				function output(msg) {
					// Response
					var m = document.getElementById('messages');
					m.innerHTML = msg;
				}

				function parseFile(file) {

					console.log(file.name);
					output('<h5>' + encodeURI(file.name) + '</h5>');

					// var fileType = file.type;
					// console.log(fileType);
					var imageName = file.name;

					var isGood = (/\.(?=gif|jpg|png|jpeg)/gi).test(imageName);
					if (isGood) {
						document.getElementById('start').classList.add("hidden");
						document.getElementById('response').classList.remove("hidden");
						document.getElementById('notimage').classList.add("hidden");
						// Thumbnail Preview
						document.getElementById('file-image').classList.remove("hidden");
						document.getElementById('file-image').src = URL.createObjectURL(file);
					} else {
						document.getElementById('file-image').classList.add("hidden");
						document.getElementById('notimage').classList.remove("hidden");
						document.getElementById('start').classList.remove("hidden");
						document.getElementById('response').classList.add("hidden");
						document.getElementById("file-upload-form").reset();
					}
				}

				function setProgressMaxValue(e) {
					var pBar = document.getElementById('file-progress');

					if (e.lengthComputable) {
						pBar.max = e.total;
					}
				}

				function updateFileProgress(e) {
					var pBar = document.getElementById('file-progress');

					if (e.lengthComputable) {
						pBar.value = e.loaded;
					}
				}

				function uploadFile(file) {

					var xhr = new XMLHttpRequest(), fileInput = document.getElementById('class-roster-file'), pBar = document.getElementById('file-progress'), fileSizeLimit = 1024;
					// In MB
					if (xhr.upload) {
						// Check if file is less than x MB
						if (file.size <= fileSizeLimit * 1024 * 1024) {
							// Progress bar
							pBar.style.display = 'inline';
							xhr.upload.addEventListener('loadstart', setProgressMaxValue, false);
							xhr.upload.addEventListener('progress', updateFileProgress, false);

							// File received / failed
							xhr.onreadystatechange = function(e) {
								if (xhr.readyState == 4) {
									// Everything is good!

									// progress.className = (xhr.status == 200 ? "success" : "failure");
									// document.location.reload(true);
								}
							};

							// Start upload
							xhr.open('POST', document.getElementById('file-upload-form').action, true);
							xhr.setRequestHeader('X-File-Name', file.name);
							xhr.setRequestHeader('X-File-Size', file.size);
							xhr.setRequestHeader('Content-Type', 'multipart/form-data');
							xhr.send(file);
						} else {
							output('Please upload a smaller file (< ' + fileSizeLimit + ' MB).');
						}
					}
				}

				// Check for the various File API support.
				if (window.File && window.FileList && window.FileReader) {
					Init();
				} else {
					document.getElementById('file-drag').style.display = 'none';
				}
			}

			ekUpload();
		</script>
		<script>
			var maxHeight = 0;

			$(".info-bx").each(function() {
				if ($(this).height() > maxHeight) {
					maxHeight = $(this).height();
				}
			});

			$(".info-bx").height(maxHeight);

		</script>

		<script>
			$(document).ready(function() {
				//change colour when radio is selected
				$('#radio-example input:radio').change(function() {
					// Only remove the class in the specific `box` that contains the radio
					$('div.highlight').removeClass('highlight');
					$(this).closest('.create-innr').addClass('highlight');
				});
			});

		</script>

		<script>
			$(function() {
				$(".clk").click(function() {
					$(".hide-inn").addClass("show-inn");
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".reset-btn").click(function() {
					$("#remove").removeClass("page-form-innr").addClass('xyz');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".next-btn").click(function() {
					$("#remove").removeClass("xyz over-follow").addClass('page-form-innr over-follow');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".reset-btn").click(function() {
					$("#progressbar").removeClass("pregress-innr").addClass('xyz');
				});
			});
		</script>

		<script>
			$(document).ready(function() {
				$(".next-btn").click(function() {
					$("#progressbar").removeClass("xyz").addClass('pregress-innr');
				});
			});
		</script>

		<script>
			var expiryMask = function() {
				var inputChar = String.fromCharCode(event.keyCode);
				var code = event.keyCode;
				var allowedKeys = [8];
				if (allowedKeys.indexOf(code) !== -1) {
					return;
				}

				event.target.value = event.target.value.replace(/^([1-9]\/|[2-9])$/g, '0$1/').replace(/^(0[1-9]|1[0-2])$/g, '$1/').replace(/^([0-1])([3-9])$/g, '0$1/$2').replace(/^(0?[1-9]|1[0-2])([0-9]{2})$/g, '$1/$2').replace(/^([0]+)\/|[0]+$/g, '0').replace(/[^\d\/]|^[\/]*$/g, '').replace(/\/\//g, '/');
			}
			var splitDate = function($domobj, value) {
				var regExp = /(1[0-2]|0[1-9]|\d)\/(20\d{2}|19\d{2}|0(?!0)\d|[1-9]\d)/;
				var matches = regExp.exec(value);
				$domobj.siblings('input[name$="expiryMonth"]').val(matches[1]);
				$domobj.siblings('input[name$="expiryYear"]').val(matches[2]);
			}

			$('input.exp').on('keyup', function() {
				expiryMask();
			});

			$('input.exp').on('focusout', function() {
				splitDate($(this), $(this).val());
			});
		</script>

		
<script>
		var DATA_COUNT = 12;

		var utils = Samples.utils;

		utils.srand(110);

		function getLineColor(ctx) {
			return utils.color(ctx.datasetIndex);
		}

		function alternatePointStyles(ctx) {
			var index = ctx.dataIndex;
			return index % 2 === 0 ? 'circle' : 'rect';
		}

		function makeHalfAsOpaque(ctx) {
			return utils.transparentize(getLineColor(ctx));
		}

		function adjustRadiusBasedOnData(ctx) {
			var v = ctx.dataset.data[ctx.dataIndex];
			return v < 10 ? 5
				: v < 25 ? 7
				: v < 50 ? 9
				: v < 75 ? 11
				: 15;
		}

		function generateData() {
			return utils.numbers({
				count: DATA_COUNT,
				min: 0,
				max: 25000
			});
		}

		var data = {
			labels: utils.months({count: DATA_COUNT}),
			
			datasets: [{
				label: 'Monthly Revenue ',
				data: generateData(),
				backgroundColor: "rgba(92,146,231,0.1)",
				borderWidth: 3,
	            borderColor: "rgba(63,138,226,1)",
	            pointBorderColor: "rgba(220,220,220,1)",
	            pointBackgroundColor: "#fff",
	            pointBorderWidth: 1,
	            pointHoverRadius: 5,
			}]
		};

		var options = {
			legend: false,
			tooltips: true,
			elements: {
				line: {
					fill: false,
					backgroundColor: '#537bc4',
					borderColor: '#537bc4',
				},
				point: {
					backgroundColor:'getLineColor' ,
					hoverBackgroundColor: 'makeHalfAsOpaque',
					radius: 'adjustRadiusBasedOnData',
					pointStyle: 'pointStyle',
					hoverRadius: 15,
					pointRadius: 0,
				}
			}
		};

		var chart = new Chart('chart-0', {
			type: 'line',
			data: data,
		 options: {
        scales: {
        	xAxes: [{ 
                gridLines: {
                    display: false,
                },
                ticks: {
                  fontColor: "#1e232a", // this here
                },
            }],
        	
            yAxes: [{
                ticks: {
                	fontColor: "#1e232a", // this here
                    beginAtZero: false,
                    callback: function (value, index, values) {
                        if (parseInt(value) >= 1000) {
                            return '$' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                        } else {
                            return '$' + value;
                        }
                    }
                }
            }]
        }
     }
		});
			
		// eslint-disable-next-line no-unused-vars
		function addDataset() {
			chart.data.datasets.push({
				data: generateData()
			});
			chart.update();
		}

		// eslint-disable-next-line no-unused-vars
		function randomize() {
			chart.data.datasets.forEach(function(dataset) {
				dataset.data = generateData();
			});
			chart.update();
		}

		// eslint-disable-next-line no-unused-vars
		function removeDataset() {
			chart.data.datasets.shift();
			chart.update();
		}
	</script>
	</body>
</html>