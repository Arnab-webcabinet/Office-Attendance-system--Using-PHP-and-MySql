<?php 
include('dbconnection.php'); 

if (isset($_POST['search'])) {
	$search=$_POST['search'];
	$search="%$search%";

	if (strlen($search) > 2) {
		$ercquery="SELECT * FROM users_information WHERE FirstName LIKE '$search' || LastName LIKE '$search' || MobileNumber LIKE '$search'";
		$query=mysqli_query($con, $ercquery);
		if (mysqli_num_rows($query) > 0) {
			$cnt=1;
			while ($row = mysqli_fetch_array($query)) {
				$pimage=base64_encode($row['UserImage']);
				$first_name=$row["FirstName"];
				$last_name=$row["LastName"];
				$name= $first_name." ".$last_name;
				$phoneno=$row["MobileNumber"];
				$email=$row["Email"];
				$timestamp = strtotime($row["CreationDate"]);
				$getodt = date('d-m-Y', $timestamp);
				$output='
				<tr>
					<td>'.$cnt.'</td>
					<td><img src="data:image/jpg;charset=utf8;base64,'.$pimage.'" width="60" height="60"></td>
					<td>'.$name.'</td>
					<td><a href="'.$email.'">'.$email.'</a></td>
					<td><a href="'.$phoneno.'">'.$phoneno.'</a></td>
					<td>'.$getodt.'</td>
					<td></td>
				</tr>
				';
			echo $output;
			}$cnt=$cnt+1;
		}else{
			echo "Data not Found..!";
		}
	}
}