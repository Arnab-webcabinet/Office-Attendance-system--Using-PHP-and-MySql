<?php 
//Databse Connection file
include('dbconnection.php');

if(isset($_POST['submit']))
  {
  	$filename = $_FILES['file']['name'];
  	$target_dir = "upload/";
  	$target_file = $target_dir . basename($_FILES["file"]["name"]);
  	//getting the post values
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $lname = mysqli_real_escape_string($con, $_POST['lname']);
    $contno = mysqli_real_escape_string($con, $_POST['contactno']);
    $email = mysqli_real_escape_string($con, $_POST['email']);  
    $dob = mysqli_real_escape_string($con, $_POST['dob']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $add = mysqli_real_escape_string($con, $_POST['address']);
    $pass = mysqli_real_escape_string($con, $_POST['password']);
    $pass = md5($pass);
    $cpass=mysqli_real_escape_string($con, $_POST['cpassword']);
    $cpass=md5($cpass);

    $ret1=mysqli_query($con,"select * from users_information where Email='".$email."'");
  	if(mysqli_num_rows($ret1) > 0){
		echo "<script>alert('Email already exists..!');</script>";  
	}else{
		// Select file type
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		// Valid file extensions
		$extensions_arr = array("jpg","jpeg","png","gif");
		$profilefile = addslashes(file_get_contents($_FILES["file"]["tmp_name"]));

		if ($pass == $cpass) {
		// Check extension
		if( in_array($imageFileType,$extensions_arr) ){
		// Upload file
		if(move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$filename)){
		$query=mysqli_query($con, "insert into users_information(UserImage,FirstName,LastName, MobileNumber, Email, dob, Gender, Address, Password) value('$profilefile','$fname','$lname', '$contno', '$email', '$dob', '$gender', '$add', '$pass')");
		if ($query) {
		echo "<script>alert('You have successfully inserted the data');</script>";
		echo "<script type='text/javascript'> document.location ='login.php'; </script>";
		}
		else
		{
		echo "<script>alert('Something Went Wrong. Please try again');</script>";
		}
		} //end upload file or not 
		} //end check exist
		} else {
			echo "<script>alert('Your Password not match with confirm Password. Please try again!');</script>";
		}
	}
}

//Code for deletion
if(isset($_GET['delid']))
{
	$rid=intval($_GET['delid']);
	$sqldel=mysqli_query($con,"delete from users_information where ID=$rid");
	if ($sqldel) {
		echo "<script>alert('Your Data deleted successfully..!');</script>"; 
		echo "<script>window.location.href = 'index.php'</script>";
	} else {
		echo "<script>alert('Oops! Something went wrong. Please try again later.');</script>";
	}    
} 
?>

<?php include('header.php'); ?>

<section class="muttiform-details-sec">
	<div class="container">
		<div class="page-form-innr show-inn">
			<form id="msform" method="post" action="" enctype='multipart/form-data'>
				<div class="form-details-outr">
					<div class="comm-hdr text-center">
						<h3>New Registration</h3>
					</div>
					<div class="frm-icon-outr text-center">
						<div class="frm-icon-innr">
							<img src="images/register_topicon.png" alt=""/>
						</div>
					</div>
					<div class="form-details-innr my-chk-input">
						<div class="row remove-mr">
							<div class="col-md-4">
								<div class="form-group">
									<label>First Name :</label>
									<input type="text" name="fname" class="form-control" placeholder="First Name">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Last Name :</label>
									<input type="text" name="lname" class="form-control" placeholder="Last Name">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Mobile Number :</label>
									<input type="tel" name="contactno" class="form-control" maxlength="10" pattern="[0-9]+">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="css">Email id :</label>
									<input type="email" class="form-control" name="email" placeholder="abc@xyz.com" required="true">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="css">Date of Birth :</label>
									<input type="date" class="form-control" name="dob" placeholder="Date of Birth" required="true">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="css">Gender :</label>
									<div class="crdt-chks customer-r-btn">
										<div class="order-des text-left">
											<label class="radio-bx">
												<input type="radio" name="gender" value="male">
												<span class="checkmark"></span> </label>
											<strong>Male</strong>
										</div>
										<div class="order-des text-left">
											<label class="radio-bx">
												<input type="radio" name="gender" value="femail">
												<span class="checkmark"></span> </label>
											<strong>Female</strong>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Address :</label>
									<input type="text" name="address" placeholder="" class="form-control">
								</div>
							</div>
						</div>
						<div class="row remove-mr">
							<div class="col-md-4">
								<div class="form-group">
									<label for="css">Password</label>
									<input type="password" class="form-control" name="password" placeholder="********" required="true"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="css">Confirm Password</label>
									<input type="password" class="form-control" name="cpassword" placeholder="********" required="true"/>
								</div>
							</div> 
							
							<div class="col-md-4">
								<div class="form-group">
									<label>Upload Profile Logo :</label>
									<div class="file-upload uploader">
										<input id="file-upload" type="file" type="file" name="file" accept="image/*" />

										<label for="file-upload" id="file-drag"> <img id="file-image" src="#" alt="Preview" class="hidden">
											<div id="start">
												<img src="images/fileup_img.png" alt="d">
												<h5>File Size
												<br>
												250*250 pixel</h5>
												<div id="notimage" class="hidden">
													img
												</div>
											</div>
											<div id="response" class="hidden">
												<div id="messages"></div>
											</div>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="text-center">
					<input type="submit" name="submit" class="btn btn-primary comm-btn register-btn" value="Register"/>
				</div>
			</form>
		</div>
	</div>
</section>

<section class="info-sec innertr_fooinfo">
	<div class="container">
		<div class="info-outr">
			<div class="row">
				<div class="col-lg-6 col-md-6">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/amff_icon1.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Withdrawals of Money</h3>
							<!-- <p>
								Credit bank account by withraw your money.
							</p> -->
							<a href="all-withdrawals.html" class="btn btn-primary comm-btn actn-btn rmv-width">Recent Withdrawals</a>
						</div>
					</div>
				</div>

				<div class="col-lg-6 col-md-6">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/amff_icon2.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Transaction of Money</h3>
							<!-- <p>
								Transfer your money to another account.
							</p> -->
							<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn rmv-width">Recent Transactions</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include('footer.php'); ?>