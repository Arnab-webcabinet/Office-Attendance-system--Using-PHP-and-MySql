<?php
//Databse Connection file
include('dbconnection.php');
?>

<?php include('header.php'); ?>

<section class="muttiform-details-sec">
	<div class="container">
		<div class="page-form-innr show-inn">
			<form id="msform">
				<div class="form-details-outr">
					<div class="frm-icon-outr text-center">
						<div class="frm-icon-innr">
							<img src="images/privacy-icn.png" alt=""/>
						</div>
					</div>
					<div class="comm-hdr text-center">
						<h3>PRIVACY POLICY</h3>
					</div>

					<div class="privacy-outr">
						<div class="privacny-hdr">
							<h3>Privacy Policy</h3>
							<p>
								This privacy policy (“Policy”) describes how Flatstack, LLC and its related companies (“Company”) collect, use and share personal information of consumer users of this website, flatstack.com (the “Site”). This Policy also applies to any of our other websites that post this Policy. This Policy does not apply to websites that post different statements.
							</p>

						</div>

						<div class="privacny-hdr">
							<h4>What We Collect</h4>
							<p>
								We get information about you in a range of ways.
							</p>

							<!-- <div class="privacysub-hdr"> -->
							<h5>Information You Give Us</h5>

							<p>
								We collect your name, email address, phone number, and other information you directly give us on our Site.
							</p>
							<!-- </div> -->

							<!-- 	<div class="privacysub-hdr">
							<h5>Information You Give Us</h5>

							<p>We collect your name, email address, phone number, and other information you directly give us on our Site.</p>
							</div>
							<div class="privacysub-hdr">
							<h5>Information You Give Us</h5>

							<p>We collect your name, email address, phone number, and other information you directly give us on our Site.</p>
							</div> -->

							<h5>Information Automatically Collected</h5>

							<p>
								We automatically log information about you and your computer. For example, when visiting our Site, we log browser type, pages you viewed, how long you spent on a page and information about your use of and actions on our Site.
							</p>

							<h5>Cookies</h5>

							<p>
								We may log information using "cookies." Cookies are small data files stored on your hard drive by a website. Cookies help us make our Site and your visit better. We use cookies to see which parts of our Site people use and like and to count visits to our Site.
							</p>

							<h5>Web Beacons</h5>
							<p>
								We may log information using digital images called Web beacons on our Site or in our emails. We use Web beacons to manage cookies, count visits, and to learn what marketing works and what does not. We also use Web Beacons to tell if you open or act on our emails.
							</p>
						</div>

						<div class="privacny-hdr">
							<h4>Use of personal information</h4>
							<p>
								We use your personal information as follows:
							</p>
							<p>
								We use your personal information to operate, maintain, and improve our sites, products, and services.
							</p>
							<p>
								We use your personal information to respond to comments and questions and provide customer service.
							</p>
							<p>
								We use your personal information to provide and deliver products and services customers request
							</p>
						</div>

						<div class="privacny-hdr">
							<h4>Sharing of personal information</h4>
							<p>
								We may share personal information with your consent. For example, you may let us share
								personal information with others for their own marketing uses. Those uses will be subject to their privacy policies.
							</p>
							<p>
								We may share personal information when we do a business deal, or negotiate a business deal, involving sale or transfer of all or a part of our business or assets. These deals can include any merger, financing,
								acquisition, or bankruptcy transaction or proceeding.
							</p>
							<p>
								We may share personal information for legal, protection, and safety purposes.
							</p>
							<p>
								We may share information to comply with laws.
							</p>
							<p>
								We may share information to respond to lawful requests and legal process.
							</p>

							<p>
								We may share information to protect the rights and property of Flatstack, LLC, our agents,
								customers, and others. This includes enforcing our agreements, policies, and terms of use.
							</p>

							<p>
								We may share information in an emergency. This includes protecting the safety of our
								employees and agents, our customers, or any person.
							</p>

							<p>
								We may share information with those who need it to do work for us.
							</p>
							<p>
								We may also share aggregated and/or anonymized data with others for their own uses.
							</p>

						</div>
						
						
						
						<div class="privacny-hdr">
							<h4>Information choices and changes</h4>
							<p>
								Our marketing emails tell you how to “opt-out.” If you opt out, we may still send you non-marketing emails. Non-marketing emails include emails about your accounts and our business dealings with you.
							</p>
							<p>
								You may send requests about personal information to our Contact Information below. You can request to change contact choices, opt-out of our sharing with others, and update your personal information.
							</p>
							<p>
								You can typically remove and reject cookies from our Site with your browser settings. Many browsers are set to accept cookies until you change your settings. If you remove or reject our cookies, it could affect how our Site works for you.
							</p>

						</div>
						
						
						<div class="privacny-hdr">
							<h4>Security of your personal information</h4>
							<p>
								We take steps to help protect personal information. No company can fully prevent security risks, however. Mistakes may happen. Bad actors may defeat even the best safeguards.
							</p>
						</div>
						
						<div class="privacny-hdr">
							<h4>Contact information</h4>
							<p>
								We welcome your comments or questions about this Privacy Policy. You may also contact us at our address: 643 Magazine St. Suite 102 New Orleans, LA 70130
							</p>
						</div>
						
						<div class="privacny-hdr">
							<h4>Changes to this privacy policy</h4>
							<p>
								We may change this Privacy Policy. If we make any changes, we will change the Last Updated date below.
							</p>
						</div>
						

					</div>
				</div>
			</form>
		</div>
	</div>
</section>

<section class="info-sec">
	<div class="container">
		<div class="info-outr">
			<div class="row">
				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn1.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Add New Store</h3>
							<p>
								The <strong> first step </strong>is to choose how you want to position the store.
							</p>
							<a href="all-withdrawals.html" class="btn btn-primary comm-btn actn-btn">Add Now</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn2.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>FAQs</h3>
							<p>
								<strong> Frequently asked questions </strong>and answers on a particular topic.
							</p>
							<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">View</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn3.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Need Help?</h3>
							<p>
								If you <strong> need any type of help </strong> our services, we are always to help you.
							</p>
							<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">Get In TOuch</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include('footer.php'); ?>