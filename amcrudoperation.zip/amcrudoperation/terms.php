<?php
//Databse Connection file
include('dbconnection.php');
?>

<?php include('header.php'); ?>

<section class="muttiform-details-sec">
	<div class="container">
		<div class="page-form-innr show-inn">
			<form id="msform">
				<div class="form-details-outr">
					<div class="frm-icon-outr text-center">
						<div class="frm-icon-innr">
							<img src="images/terms-icn.png" alt=""/>
						</div>
					</div>
					<div class="comm-hdr text-center">
						<h3>TERMS & CONDITIONS</h3>
					</div>

					<div class="privacy-outr">
						<div class="privacny-hdr">
							<h3>Monthly Website Payment Plan Terms & Conditions</h3>
							<p>
								<strong>Deposit :</strong> Before the project begins, three monthly instalments will be collected. You will receive this deposit back once the the fixed term has been paid after the 24 month commitment. There is no interest to be paid on this deposit.
							</p>

							<p>
								<strong>Monthly Payments :</strong> Payment must clear by the 7th day of each month. Uncleared funds may result in a
								service suspension. Invoice: You will be invoiced by the 1st of each month.
							</p>

							<p>
								<strong> Monthly Payment Plan :</strong> If you choose to sign on to a 24 month contract, it is 20% more expensive than paying upfront. After your contract is completely paid, your payments will become only the price of your hosting fee.
							</p>

							<p>
								<strong> Annual Escalation :</strong> A 10% annual escalation is applicable.
							</p>

							<p>
								<strong>Website Warranty : </strong>You are covered by a ClearSolid maintenance plan for 90 days after the launch of your website. This plan includes any bugs or Issues that arise.
							</p>

							<p>
								<strong> Maintenance :</strong> Any Issues that arise after your warranty period will be charged at our hourly
								maintenance rate.
							</p>
							<p>
								<strong>Moving on :</strong> If in the future, you wish to move your website to another provider, a fee will be applicable to cover preparation and packaging of your data, and content files. This fee Is not associated with the new provider's charges. The website and it's content remains the property of ClearSolid until full payment has been received.
							</p>
						</div>

						<div class="privacny-hdr">
							<h3>SEO Terms & Conditions</h3>
							<p>
								<strong>Contract commitment : </strong>The minimum contract period is 6 months. A 3 month notice is required for ancellation.
							</p>

							<p>
								<strong>Monthly Payments :</strong> Payment must clear by the 7th day of each month. Uncleared funds may result in a
								service suspension.
							</p>

							<p>
								<strong>Invoice : </strong>Invoices are distributed quarterly. Payments are due monthly.
							</p>
							<p>
								<strong>Liability :</strong> ClearSolid are not liable for any claim by the customer or any third party that should arise.
							</p>

							<p>
								<strong> Authority : </strong>The customer hereby authorizes ClearSolid access to their domain, hosting accounts, databases associated with the services, and to publish material to search engines and other directories without
								liability.
							</p>

							<p>
								<strong>For SEO services, the customer agrees to provide : </strong>Administrative access to the website for content
								analysis. Permission to make changes for the purpose of search engine optimization, and permission to communicate with third parties for the purpose of optimization. Unlimited access to website traffic and
								statistics is required for analysis.
							</p>

							<p>
								ClearSolid is not responsible for the policies of search engines with respect to the type of content that they accept now or in the future. Your website may be excluded from any search engine at any time at their sole discretion.
							</p>

							<p>
								Due to the competitiveness of keywords or phrases and ongoing changes in search engine ranking
								algorithms, positions cannot be guaranteed in any search engine.
							</p>

							<p>
								Google has been known to hinder the rankings of new website pages until they have proven their viability to exist for more than a period of time. This Is referred to as the "Google Sandbox, ClearSolid assumes no liability issues related to Googie Sandbox penalties.
							</p>
							<p>
								Occasionally, search engines will drop listings for no apparent reason. The listing will often reappear
								without any additional SEO. We assume no liability for such de-listings/listings.
							</p>

							<p>
								Some search directories offer expedited listing services for a fee. If the customer wishes to engage In these services, the customer is responsible for all fees.
							</p>
							<p>
								Linking to sites such as "bad neighbourhoods' or getting links from "link farms" can damage all SEO efforts. ClearSolid assumes no liability for the customer, choice to link to or obtain a link from any particular
								website without prior consultation.
							</p>

							<p>
								Clear Solid is not responsible for any changes made to the website by third parties that affect the search engine rankings of the customer's website.
							</p>

							<p>
								Clear Solid is not responsible for the customer overwriting optimized SEO content.
							</p>
						</div>

						<div class="privacny-hdr">
							<h3>Maintenance Plan Terms & Conditions</h3>
							<p>
								A maintenance retainer is offered as an available service to fix any issues, including (but not limited to)
								bug fixing, website changes, enhancements and new features.
							</p>
							<p>
								All maintenance retainer contracts are less expensive than our hourly maintenance fee. If you go over your monthly hours then our standard hourly rate will apply.
							</p>

							<p>
								Unused hours will roll-over into the next month. Unused hours for more than 2 months will be lost. Your
								will be provided with an itemized breakdown of how the hours were used each month.
							</p>
							<p>
								You will be invoiced monthly In advance.
							</p>

							<p>
								A minimum maintenance contract is 3 months with 1 months' notice. If you took signed on to the minimum number of months and then wanted to cancel your retainer contract, it would equate to 3 months +1 months' notice, which would equal 4 months payments. After 3 months, the retainer will continue to roll month by month, with a minimum of 1 months' notice period.
							</p>
						</div>

						<div class="privacny-hdr">
							<h3>Website Hosting Terms & Conditions</h3>
							<p>
								<strong>Monthly Payments :</strong> Payment must clear by the 7th day of each month. Uncleared funds may result in a
								service suspension.
							</p>
							<p>
								<strong>Cancellation : </strong>There is a 1 month notice period we require when cancelling your website hosting. Written notice must be emailed in before the 1st of the month. For example, if you would like to cancel your
								website hosting as of 1st July, then ensure that written notice is provided by the 1st of June.
							</p>
						</div>

					</div>
				</div>
			</form>
		</div>
	</div>
</section>

<section class="info-sec">
	<div class="container">
		<div class="info-outr">
			<div class="row">
				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn1.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Add New Store</h3>
							<p>
								The <strong> first step </strong>is to choose how you want to position the store.
							</p>
							<a href="all-withdrawals.html" class="btn btn-primary comm-btn actn-btn">Add Now</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn2.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>FAQs</h3>
							<p>
								<strong> Frequently asked questions </strong>and answers on a particular topic.
							</p>
							<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">View</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4">
					<div class="info-bx">
						<div class="info-icn">
							<img src="images/info-icn3.png" alt=""/>
						</div>
						<div class="info-des">
							<h3>Need Help?</h3>
							<p>
								If you <strong> need any type of help </strong> our services, we are always to help you.
							</p>
							<a href="all-transaction.html" class="btn btn-primary comm-btn actn-btn">Get In TOuch</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include('footer.php'); ?>