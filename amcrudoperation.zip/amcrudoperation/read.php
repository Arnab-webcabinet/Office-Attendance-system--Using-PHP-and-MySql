<?php 
//Databse Connection file
include('dbconnection.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AM- CRUD Operation</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="read_sec container">
    <h2>Crud Oparation #Read User Information</h2>
    <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">    
      <tbody>
      <?php
      $vid=$_GET['viewid'];
      $ret=mysqli_query($con,"select * from users_information where ID =$vid");
      $cnt=1;
      while ($row=mysqli_fetch_array($ret)) {
      ?>
       <tr>
          <th>Name</th>
          <td><?php  echo $row['FirstName']." ". $row['LastName'];?></td>
          <th>Date of Birth</th>
          <td><?php  echo $row['dob'];?></td>
        </tr>
        <tr>
          <th>Email</th>
          <td><?php  echo $row['Email'];?></td>
          <th>Mobile Number</th>
          <td><?php  echo $row['MobileNumber'];?></td>
        </tr>
        <tr>
          <th>Address</th>
          <td><?php  echo $row['Address'];?></td>
          <th>Creation Date</th>
          <td><?php  echo $row['CreationDate'];?></td>
        </tr>
      <?php 
      $cnt=$cnt+1;
      }?>              
      </tbody>
    </table>
    <div class="row">
      <div class="col text-center">
        <a href="index.php" class="btn btn-success btn-info">Back to Index</a>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>