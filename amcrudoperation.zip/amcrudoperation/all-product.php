<?php
include('dbconnection.php');
include('header.php'); 
?>

<section class="views-all-store-sec">
	<div class="container">
		<div class="commn-border">
			<div class="comm-hdr text-center">
				<h3>View All Products</h3>
			</div>

			<div class="search-outr">
				<form>
					<input type="text" placeholder="Search by Product name.." class="form-control">
					<input type="submit" class="frm-sbmt" value="Search">
				</form>
			</div>

			<div class="all-store-manager-box">
				<h3>All Sales Associates</h3>
				<div class="table-overflow">
					<div class="table-width">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Product Img.</th>
									<th>Product Name</th>
									<th>Category</th>
									<th>Regular Price</th>
									<th>Sale Price</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody class="produlist_bdy">
								<?php
								$ret=mysqli_query($con,"select * from product_tbl order by date DESC");
								$cnt=1;
								$row=mysqli_num_rows($ret);
								if($row>0){
								while ($row=mysqli_fetch_array($ret)) {
								?>
								<tr>
									<td><img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['ProductImage']); ?>" class="proimg" alt=""/></td>
									<td><?php echo $row['ProductName']; ?></td>
									<td><?php echo $row['product_category']; ?></td>
									<td><?php echo '$'. $row['product_regular_price']; ?></td>
									<td><?php echo '$'. $row['product_sale_price']; ?></td>
									<td>
									<div class="action-btn">
										<a href="edit.php?editid=<?php echo htmlentities ($row['ID']);?>" class="archive-icn"><img src="images/edit.png" alt=""/></a>
										<a href="read.php?viewid=<?php echo htmlentities ($row['ID']);?>"><img src="images/view-icn.png" alt=""/></a>
										<a href="register.php?delid=<?php echo ($row['ID']);?>" title="Delete" data-toggle="tooltip" onclick="return confirm('Do you really want to Delete ?');"><img src="images/delete-icn.png" alt=""/></a>
									</div></td>
								</tr>
								<?php 
								$cnt=$cnt+1;
								} } else {?>
						     	<tr>
									<td style="text-align:center; color:red;" colspan="7">No Record Found</td>
								</tr>
								<?php } ?> 
							</tbody>
						</table>
					</div>
				</div>
				<div class="pagination-outr">

					<div class="per-page">
						<ul>
							<li>
								<div class="box">
									<select>
										<option>10 per Page</option>
										<option>5 per Page</option>
									</select>
								</div>
							</li>

							<li>
								<a href="javascript:void(0);">Prev.</a>
							</li>
							<li>
								<a href="javascript:void(0);">Next</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include('footer.php'); ?>